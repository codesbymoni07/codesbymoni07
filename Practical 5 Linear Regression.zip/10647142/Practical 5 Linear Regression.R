#Linear Regression
#Practical 5 
#Author: Paula Monique Diharjo

#Example 1.2 
#Step 1 - Define the dataset
X <- c(0,2,4,6,8) #Quiz 1 data
Y <- c(6,5,8,7,9) #Quiz 2 data

# Step 2 - Visualise the data
plot(Y ~ X, col = "blue",
     main = "Scatter Diagram",
     xlab = "Quiz 1", ylab = "Quiz 2") #plot scatter diagram

# Step 2 - Visualise the data
plot(Y ~ X, col = "blue",
     main = "Scatter Diagram",
     xlab = "Quiz 1", ylab = "Quiz 2") #plot scatter diagram

# Step 3 - Modeling (SLR)
FitLine <- lm(Y ~ X); FitLine #estimate parameters
Yhat <- predict(FitLine) #predict using X
Yhat 

# Step 4 - Plot the model
abline(FitLine, col="red") #add regression line on the scatter diagram

# Step 5 - Evaluate the model
?qf #quartile function for f distribution  (p, df1, df2, lower)
anova(FitLine) #test significance of the regression
Fcv <- qf(0.95,1,3); Fcv
Fcv <- qf(0.95,1,3)
Fcv <- qf (0.05,1,3, lower.tail= False)
Fcv

#2) Test significance of the X individual variable 
#t-test 
test <- summary(FitLine); test #test significance of the individual variable
tcvl <- qt(0.025,3); tcvl #Left tail
tcvr <- qt(0.975,3); tcvr #Right tail

R = cor(X,Y) #correlation
R_Square <-R**2 

#Confidence and Prediction Interval 
confint(FitLine) #confidence interval of the estimators
#Confidence interval of the mean response, E(X)
predict(FitLine, newdata=data.frame(X=7), interval='confidence', level=0.95)
#Prediction interval
predict(FitLine, newdata=data.frame(X=6), interval='prediction', level=0.95)

#Plot confidence interval of the mean response
library(ggplot2)
quiz <- as.data.frame(cbind(X,Y)) #set up data frame
ggplot(quiz, aes(x=X, y=Y)) +
  geom_point() +
  geom_smooth(method="lm", formula = y ~ x, colour = 'blue') +
  ggtitle('Scatter Diagram') +
xlab('Quiz 1') +
ylab('Quiz 2')